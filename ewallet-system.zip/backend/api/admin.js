const express = require("express")
const router = express.Router()

const db = require("../services/firebase")

router.get("/users", async(req,res)=>{

 const snapshot = await db.collection("users").get()

 const users = []

 snapshot.forEach(doc=>{
  users.push(doc.data())
 })

 res.json(users)

})

router.get("/transactions", async(req,res)=>{

 const snapshot = await db.collection("transactions").get()

 const tx=[]

 snapshot.forEach(doc=>{
  tx.push(doc.data())
 })

 res.json(tx)

})

module.exports = router