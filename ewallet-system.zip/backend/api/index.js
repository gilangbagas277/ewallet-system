const express = require("express")
const cors = require("cors")

const wallet = require("./wallet")
const admin = require("./admin")

const app = express()

app.use(cors())
app.use(express.json())

app.use("/wallet", wallet)
app.use("/admin", admin)

app.get("/",(req,res)=>{
 res.json({status:"ewallet api running"})
})

module.exports = app