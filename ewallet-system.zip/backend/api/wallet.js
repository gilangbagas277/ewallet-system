const express = require("express")
const router = express.Router()

const db = require("../services/firebase")
const { validateAmount } = require("../services/security")

router.post("/topup", async(req,res)=>{

 const { uid, amount } = req.body

 if(!validateAmount(amount)){
  return res.status(400).json({error:"invalid amount"})
 }

 const ref = db.collection("users").doc(uid)
 const user = await ref.get()

 if(!user.exists){
  return res.status(404).json({error:"user not found"})
 }

 const balance = user.data().balance + amount

 await ref.update({balance})

 await db.collection("transactions").add({
  type:"topup",
  uid,
  amount,
  status:"success",
  createdAt:Date.now()
 })

 res.json({success:true,balance})

})

router.post("/transfer", async(req,res)=>{

 const {sender,receiver,amount} = req.body

 if(!validateAmount(amount)){
  return res.status(400).json({error:"invalid amount"})
 }

 const senderRef = db.collection("users").doc(sender)
 const receiverRef = db.collection("users").doc(receiver)

 const senderDoc = await senderRef.get()
 const receiverDoc = await receiverRef.get()

 if(!senderDoc.exists || !receiverDoc.exists){
  return res.status(404).json({error:"user not found"})
 }

 const senderBalance = senderDoc.data().balance

 if(senderBalance < amount){
  return res.status(400).json({error:"insufficient balance"})
 }

 await senderRef.update({
  balance: senderBalance - amount
 })

 await receiverRef.update({
  balance: receiverDoc.data().balance + amount
 })

 await db.collection("transactions").add({
  type:"transfer",
  sender,
  receiver,
  amount,
  status:"success",
  createdAt:Date.now()
 })

 res.json({success:true})

})

module.exports = router