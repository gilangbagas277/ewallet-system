module.exports = function(req,res,next){

 const token = req.headers["x-api-key"]

 if(!token){
  return res.status(403).json({error:"unauthorized"})
 }

 if(token !== process.env.API_KEY){
  return res.status(401).json({error:"invalid api key"})
 }

 next()
}