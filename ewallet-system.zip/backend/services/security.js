function validateAmount(amount){

 if(!amount) return false
 if(isNaN(amount)) return false
 if(amount <= 0) return false

 return true
}

module.exports = { validateAmount }