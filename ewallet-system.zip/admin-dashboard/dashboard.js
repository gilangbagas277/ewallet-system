import { getUsers, getTransactions } from "./api.js"
import { formatCurrency, showLoading, hideLoading } from "./utils.js"

async function loadUsers(){

 showLoading()

 try{

  const users = await getUsers()

  let html=""

  users.forEach(u=>{

   html+=`
   <tr>
   <td>${u.email}</td>
   <td>${formatCurrency(u.balance)}</td>
   </tr>
   `

  })

  document.getElementById("users").innerHTML = html

 }catch(e){

  alert("failed load users")

 }

 hideLoading()

}

async function loadTransactions(){

 showLoading()

 try{

  const tx = await getTransactions()

  let html=""

  tx.forEach(t=>{

   html+=`
   <tr>
   <td>${t.type}</td>
   <td>${formatCurrency(t.amount)}</td>
   <td>${t.status}</td>
   </tr>
   `

  })

  document.getElementById("transactions").innerHTML = html

 }catch(e){

  alert("failed load transactions")

 }

 hideLoading()

}

loadUsers()
loadTransactions()