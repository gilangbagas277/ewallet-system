// Environment
const ENV = "production"

// Backend URLs
const DEV_API = "http://localhost:3000"
const PROD_API = "https://your-backend.vercel.app"

// API Base
export const API_BASE_URL = ENV === "production" ? PROD_API : DEV_API

// API KEY
export const API_KEY = "EWALLET_SECRET_KEY"

// Firebase configuration
export const firebaseConfig = {
 apiKey: "YOUR_API_KEY",
 authDomain: "your-project.firebaseapp.com",
 projectId: "your-project-id",
 storageBucket: "your-project.appspot.com",
 messagingSenderId: "123456789",
 appId: "1:123456:web:abcdef"
}

// App configuration
export const APP_CONFIG = {
 appName: "Ewallet Admin",
 version: "2.0.0",
 currency: "IDR",
 refreshInterval: 15000
}