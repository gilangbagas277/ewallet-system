import { API_BASE_URL, API_KEY } from "./config.js"

async function request(endpoint){

 const res = await fetch(API_BASE_URL + endpoint,{
  headers:{
   "Content-Type":"application/json",
   "x-api-key":API_KEY
  }
 })

 if(!res.ok){
  throw new Error("API ERROR")
 }

 return res.json()
}

export async function getUsers(){
 return request("/admin/users")
}

export async function getTransactions(){
 return request("/admin/transactions")
}