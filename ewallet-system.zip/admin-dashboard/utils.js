export function formatCurrency(amount){

 return new Intl.NumberFormat("id-ID",{
  style:"currency",
  currency:"IDR"
 }).format(amount)

}

export function showLoading(){

 document.getElementById("loading").style.display="block"

}

export function hideLoading(){

 document.getElementById("loading").style.display="none"

}